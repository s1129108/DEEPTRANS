#!/usr/bin/env python
# coding: utf-8
"""
Test a saved DeepTrans model on unseen data.

Example
-------
python DEEPTRANS_model.py -x ABC_2025.npy -w ../Model_MSCNN_RAG_class1_1000_prottrans_2_4_6_8_10.h5 -o name_extension
"""

import argparse
import os
import numpy as np
import tensorflow as tf
from tensorflow.keras import layers, Model
from sklearn.metrics import accuracy_score, roc_auc_score
import pandas as pd

# ───────────────────────────────────────── constants
NUM_FILTER     = 256
NUM_HIDDEN     = 500
WINDOW_SIZES   = [2, 4, 6, 8, 10]
NUM_CLASSES    = 2                     # modify if your model was trained with >2 classes
# ───────────────────────────────────────────────────

# ───────────────────────────────────────── DeepTrans architecture
class DeepTrans(Model):
    def __init__(self,
                 maxseq: int,
                 num_feat: int,
                 window_sizes=WINDOW_SIZES,
                 num_filters=NUM_FILTER,
                 num_hidden=NUM_HIDDEN):
        super().__init__()
        self.convs, self.pools = [], []

        for w in window_sizes:
            self.convs.append(
                layers.SeparableConv2D(filters=num_filters,
                                       kernel_size=(1, w),
                                       activation="relu",
                                       padding="valid"))
            self.pools.append(
                layers.MaxPooling2D(pool_size=(1, maxseq - w + 1),
                                    strides=(1, maxseq - w + 1))
            )

        self.flatten = layers.Flatten()
        self.dropout = layers.Dropout(0.7)
        self.dense1  = layers.Dense(num_hidden, activation="relu")
        self.dense2  = layers.Dense(NUM_CLASSES,
                                    activation="softmax",
                                    kernel_regularizer=tf.keras.regularizers.l2(1e-3))

    def call(self, x, training=False):
        feats = []
        for conv, pool in zip(self.convs, self.pools):
            h = pool(conv(x))
            feats.append(self.flatten(h))
        x = tf.concat(feats, axis=1)
        x = self.dropout(x, training=training)
        x = self.dense1(x)
        return self.dense2(x)
# ───────────────────────────────────────────────────

def build_and_load(maxseq, num_feat, weights_path):
    model = DeepTrans(maxseq=maxseq, num_feat=num_feat)
    model.compile(optimizer="adam",
                  loss="categorical_crossentropy",
                  metrics=["accuracy"])
    # model needs to be built before loading weights
    dummy_input = tf.zeros((1, 1, maxseq, num_feat))
    model(dummy_input, training=False)
    model.load_weights(weights_path)
    return model

def main():
    parser = argparse.ArgumentParser(description="Evaluate DeepTrans on unseen data.")
    parser.add_argument("-x", "--x_path", required=True,
                        help="Path to .npy file containing unseen input tensor (N,1,MAXSEQ,NUM_FEATURE)")
    parser.add_argument("-w", "--weights", default="model.h5",
                        help="Keras weights file (h5) of the trained DeepTrans model.")
    parser.add_argument("-y", "--y_path", default=None,
                        help="Optional .npy file with integer labels (N,) for evaluation.")
    parser.add_argument("-o", "--out_prefix", default="deeptrans_test",
                        help="Prefix for output files (probabilities, labels).")
    args = parser.parse_args()

    # ─── load X
    X = np.load(args.x_path)
    if X.ndim != 4 or X.shape[1] != 1:
        raise ValueError("Input tensor must have shape (N, 1, MAXSEQ, NUM_FEATURE)")
    _, _, MAXSEQ, NUM_FEATURE = X.shape

    print(f"Loaded X: {X.shape}  (MAXSEQ={MAXSEQ}, NUM_FEATURE={NUM_FEATURE})")

    # ─── build model & load weights
    model = build_and_load(MAXSEQ, NUM_FEATURE, args.weights)
    print("Model weights loaded.")

    # ─── inference
    probs = model.predict(X, batch_size=32, verbose=1)               # (N, NUM_CLASSES)
    pred_labels = np.argmax(probs, axis=1)

    num_positive = np.sum(pred_labels == 1)
    print(f"Number of predicted_label == 1: {num_positive}")
    
    # Build a DataFrame: one row per sample
    df_out = pd.DataFrame({
        "sample_index": np.arange(len(pred_labels)),
        **{f"prob_class{i}": probs[:, i] for i in range(probs.shape[1])},
        "predicted_label": pred_labels,
        "annotation": np.where(pred_labels == 1, "PAT", "Not PAT")
    })

    csv_path = f"{args.out_prefix}_predictions.csv"
    df_out.to_csv(csv_path, index=False)
    print(f"Saved predictions to {csv_path}")

    # ─── optional evaluation
    if args.y_path:
        y_true = np.load(args.y_path).astype(int)
        if y_true.shape[0] != X.shape[0]:
            raise ValueError("Label file length does not match number of samples in X.")
        acc = accuracy_score(y_true, pred_labels)
        try:
            auc = roc_auc_score(y_true, probs[:, 1])
        except ValueError:
            auc = float("nan")
        print(f"Accuracy: {acc:.4f}   AUROC: {auc:.4f}")
        # save quick metrics text file
        with open(f"{args.out_prefix}_metrics.txt", "w") as f:
            f.write(f"Accuracy\t{acc:.6f}\nAUROC\t{auc:.6f}\n")

if __name__ == "__main__":
    main()
